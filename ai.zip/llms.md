# fhir.education.kursig#0.1.0: Kevins test-IG

## Pages

* [Hem](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [Education Patient](StructureDefinition-EducationPatient.md)

### ImplementationGuides

* [Kevins test-IG](index.md)

### Examples

* [patient-tolvan (Patient)](Patient-patient-tolvan.md)
